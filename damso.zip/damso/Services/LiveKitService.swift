import Foundation
import Combine
#if canImport(LiveKit)
import LiveKit

@MainActor
class LiveKitService: NSObject, ObservableObject {
    @Published var connectionState: ConnectionState = .disconnected
    @Published var reconnectMode: ReconnectMode?
    @Published var errorMessage: String?
    
    // 근본 해결: Room 객체는 앱 생명주기 동안 딱 하나만 존재해야 합니다.
    let room: Room
    let localMedia: LocalMedia
    
    private func debugLog(_ message: String) {
        #if DEBUG
        print("[LiveKitService] \(message)")
        #endif
    }
    
    override init() {
        let r = Room()
        self.room = r
        self.localMedia = LocalMedia(room: r)
        super.init()
        self.room.add(delegate: self)
    }
    
    func connect(token: String) async throws {
        debugLog("Connecting to \(AppConfig.liveKitServerURL)")
        
        // 기존 연결이 있다면 정리만 하고 객체는 유지
        if room.connectionState != .disconnected {
            await room.disconnect()
        }
        
        let audioOptions = AudioCaptureOptions(
            echoCancellation: true,
            autoGainControl: true,
            noiseSuppression: true,
            typingNoiseDetection: true
        )
        
        let roomOptions = RoomOptions(defaultAudioCaptureOptions: audioOptions)
        let connectOptions = ConnectOptions(autoSubscribe: true, reconnectAttempts: 10)
        
        // 기존 객체(room)로 다시 연결
        try await room.connect(
            url: AppConfig.liveKitServerURL,
            token: token,
            connectOptions: connectOptions,
            roomOptions: roomOptions
        )
        
        try await room.localParticipant.setMicrophone(enabled: true)
        let captureOptions = CameraCaptureOptions(dimensions: .h1080_169)
        try await room.localParticipant.setCamera(enabled: true, captureOptions: captureOptions)
        
        self.objectWillChange.send()
    }
    
    func disconnect() async {
        await room.disconnect()
        self.connectionState = .disconnected
    }
    
    func setRemoteAudioEnabled(_ enabled: Bool) async {
        for participant in room.remoteParticipants.values {
            for publication in participant.audioTracks {
                if let track = publication.track as? RemoteAudioTrack {
                    if enabled { try? await track.start() } else { try? await track.stop() }
                }
            }
        }
    }
}

// MARK: - RoomDelegate
extension LiveKitService: RoomDelegate {
    nonisolated func room(_ room: Room, didUpdateConnectionState connectionState: ConnectionState, from oldConnectionState: ConnectionState) {
        Task { @MainActor in
            self.connectionState = connectionState
            if connectionState == .connected { self.errorMessage = nil }
            self.objectWillChange.send()
        }
    }
    
    nonisolated func room(_ room: Room, participant: Participant, didUpdateIsSpeaking isSpeaking: Bool) {
        if participant is LocalParticipant {
            Task { @MainActor in
                if isSpeaking { debugLog("🎤 VAD: Speaking") } else { debugLog("🤫 VAD: Silent") }
            }
        }
    }
    
    nonisolated func room(_ room: Room, participantDidConnect participant: RemoteParticipant) {
        Task { @MainActor in
            self.objectWillChange.send()
        }
    }

    nonisolated func room(_ room: Room, participantDidDisconnect participant: RemoteParticipant) {
        Task { @MainActor in
            self.objectWillChange.send()
        }
    }
    
    nonisolated func room(_ room: Room, participant: RemoteParticipant, didSubscribe track: RemoteTrack, publication: RemoteTrackPublication) {
        Task { @MainActor in
            debugLog("Track subscribed: \(track.kind)")
            self.objectWillChange.send() 
        }
    }
    
    nonisolated func room(_ room: Room, participant: RemoteParticipant, didUnsubscribe track: RemoteTrack, publication: RemoteTrackPublication) {
        Task { @MainActor in
            self.objectWillChange.send()
        }
    }
    
    private nonisolated func room(_ room: Room, participant: Participant, didUpdatePublication publication: RemoteTrackPublication) {
        Task { @MainActor in
            self.objectWillChange.send()
        }
    }

    private nonisolated func room(_ room: Room, participant: Participant, didUpdateTrack track: RemoteTrack) {
        Task { @MainActor in
            self.objectWillChange.send()
        }
    }
}
#endif
